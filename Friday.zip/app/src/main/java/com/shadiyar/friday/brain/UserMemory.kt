package com.shadiyar.friday.brain

import android.content.Context

/** Память пользователя: «запомни: ключ = значение», «забудь ключ». */
object UserMemory {
    private fun p(ctx: Context) = ctx.getSharedPreferences("memory", Context.MODE_PRIVATE)
    private fun norm(s: String) = NaiveBayes.tokens(s).joinToString(" ")

    fun remember(ctx: Context, k: String, v: String) { p(ctx).edit().putString(norm(k), v.trim()).apply() }

    fun forget(ctx: Context, k: String): Boolean {
        val n = norm(k)
        if (!p(ctx).contains(n)) return false
        p(ctx).edit().remove(n).apply(); return true
    }

    /** Ищем запись, все слова-ключи которой есть в вопросе. */
    fun recall(ctx: Context, q: String): String? {
        val qt = NaiveBayes.tokens(q).toSet()
        return p(ctx).all.entries
            .filter { e -> val kt = e.key.split(" ").filter { it.isNotEmpty() }; kt.isNotEmpty() && qt.containsAll(kt) }
            .maxByOrNull { it.key.length }?.value as? String
    }
}
