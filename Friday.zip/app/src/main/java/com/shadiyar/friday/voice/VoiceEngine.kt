package com.shadiyar.friday.voice

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.shadiyar.friday.core.AssistantState
import com.shadiyar.friday.core.Msg
import com.shadiyar.friday.core.Speaker
import com.shadiyar.friday.core.StateBus
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File

/**
 * Офлайн-распознавание через Vosk. Два режима:
 * 1) ожидание слова «Пятница/Джарвис» (узкая грамматика — лёгко для CPU);
 * 2) приём команды (полный словарь), затем возврат к ожиданию.
 */
class VoiceEngine(private val ctx: Context, private val onText: (String) -> Unit) {
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "friday-voice").also { it.start() }
    }

    fun stop() { running = false; thread?.join(1500) }

    /** Копируем модель из assets во внутреннюю память один раз. */
    private fun modelDir(): File {
        val dst = File(ctx.filesDir, "model")
        val mark = File(dst, ".ok")
        if (!mark.exists()) {
            dst.deleteRecursively()
            copyAsset("model-ru", dst)
            mark.writeText("1")
        }
        return dst
    }

    private fun copyAsset(path: String, dst: File) {
        val list = ctx.assets.list(path) ?: emptyArray()
        if (list.isEmpty()) {
            dst.parentFile?.mkdirs()
            ctx.assets.open(path).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            list.forEach { copyAsset("$path/$it", File(dst, it)) }
        }
    }

    private fun loop() {
        val model = try {
            Model(modelDir().absolutePath)
        } catch (e: Throwable) {
            StateBus.add(Msg(false, "Голосовая модель не загрузилась: ${e.message}. Текстовый чат работает."))
            running = false
            return
        }
        val wake = Recognizer(model, 16000f, "[\"пятница\", \"джарвис\", \"эй пятница\", \"[unk]\"]")
        val cmd = Recognizer(model, 16000f)
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8000) * 2)
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            StateBus.add(Msg(false, "Микрофон недоступен, Сэр."))
            running = false; return
        }
        rec.startRecording()
        StateBus.set(AssistantState.IDLE)
        val buf = ByteArray(4000)
        var commandMode = false
        var cmdStart = 0L
        while (running) {
            val n = rec.read(buf, 0, buf.size)
            if (n <= 0 || Speaker.speaking) continue
            if (!commandMode) {
                val hit = if (wake.acceptWaveForm(buf, n)) JSONObject(wake.result).optString("text")
                          else JSONObject(wake.partialResult).optString("partial")
                if (hit.contains("пятниц") || hit.contains("джарвис")) {
                    commandMode = true; cmdStart = System.currentTimeMillis()
                    cmd.reset(); wake.reset()
                    StateBus.set(AssistantState.LISTENING)
                    Speaker.speak("Слушаю, Сэр.")
                }
            } else {
                if (cmd.acceptWaveForm(buf, n)) {
                    val t = JSONObject(cmd.result).optString("text")
                    if (t.isNotBlank()) {
                        commandMode = false; wake.reset()
                        StateBus.set(AssistantState.THINKING)
                        try { onText(t) } catch (_: Exception) {}
                        StateBus.set(AssistantState.IDLE)
                    }
                }
                if (commandMode && System.currentTimeMillis() - cmdStart > 12000) {
                    commandMode = false; wake.reset(); StateBus.set(AssistantState.IDLE)
                }
            }
        }
        rec.stop(); rec.release()
        wake.close(); cmd.close(); model.close()
    }
}
