package com.shadiyar.friday.brain

import android.content.Context

/** Цепь Маркова первого порядка: какая команда обычно идёт после текущей. */
object Markov {
    private fun p(ctx: Context) = ctx.getSharedPreferences("markov", Context.MODE_PRIVATE)

    fun record(ctx: Context, intent: String) {
        if (intent == "NONE") return
        val sp = p(ctx)
        val prev = sp.getString("prev", null)
        val e = sp.edit()
        if (prev != null) {
            val key = "t:$prev>$intent"
            e.putInt(key, sp.getInt(key, 0) + 1)
        }
        e.putString("prev", intent).apply()
    }

    /** Самый частый следующий шаг (если он встречался хотя бы 2 раза). */
    fun predict(ctx: Context, from: String): String? {
        val sp = p(ctx)
        val pre = "t:$from>"
        return sp.all.filterKeys { it.startsWith(pre) }
            .mapValues { (it.value as? Int) ?: 0 }
            .filterValues { it >= 2 }
            .maxByOrNull { it.value }?.key?.removePrefix(pre)
    }
}
