package com.shadiyar.friday

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

/** Приложение: при старте создаём каналы уведомлений. */
class FridayApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Работа Пятницы", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_BOOT, "Запуск после перезагрузки", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Напоминания и будильники", NotificationManager.IMPORTANCE_HIGH))
    }

    companion object {
        const val CH_SERVICE = "friday_service"
        const val CH_BOOT = "friday_boot"
        const val CH_ALERT = "friday_alert"
    }
}
