package com.shadiyar.friday.actions

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.shadiyar.friday.ui.MainActivity
import java.util.Calendar

/** Напоминания, таймеры, будильники и утренний брифинг через AlarmManager.setAlarmClock (работает при выключенном экране). */
object Reminders {
    fun schedule(ctx: Context, atMillis: Long, kind: String, text: String) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx, (atMillis % Int.MAX_VALUE).toInt(),
            Intent(ctx, ReminderReceiver::class.java).putExtra("kind", kind).putExtra("text", text),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(atMillis, show), pi)
    }

    /** Ближайший момент с заданными часами и минутами (сегодня или завтра). */
    fun nextAt(h: Int, m: Int): Long {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    fun scheduleBriefing(ctx: Context) = schedule(ctx, nextAt(8, 0), "briefing", "")
}
