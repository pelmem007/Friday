package com.shadiyar.friday.brain

import android.content.Context

/** База знаний из assets/kb/facts*.txt (строка: «ключи через запятую|ответ»). Новые файлы facts_*.txt подхватываются сами. */
object Knowledge {
    private class Fact(val keys: Set<String>, val text: String)
    private var facts: List<Fact> = emptyList()
    private var jokes: List<String> = emptyList()
    private val stop = setOf("что", "такое", "расск", "про", "об", "како", "какой", "какая", "кто", "это", "мне",
        "как", "почем", "зачем", "скажи", "знаеш", "есть", "ли", "и", "в", "на", "из", "а", "о", "где", "когда", "сколь")

    private fun lines(ctx: Context, name: String): List<String> = try {
        ctx.assets.open(name).bufferedReader(Charsets.UTF_8).readLines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
    } catch (e: Exception) { emptyList() }

    fun load(ctx: Context) {
        if (facts.isNotEmpty()) return
        val files = (ctx.assets.list("kb") ?: emptyArray()).filter { it.startsWith("facts") }
        facts = files.flatMap { lines(ctx, "kb/$it") }.mapNotNull { l ->
            val i = l.indexOf('|')
            if (i < 0) null else Fact(l.substring(0, i).split(',').flatMap { NaiveBayes.tokens(it) }.toSet(), l.substring(i + 1).trim())
        }
        jokes = lines(ctx, "kb/jokes.txt")
    }

    /** Возвращает (ответ, число совпавших ключевых слов). */
    fun search(q: String): Pair<String, Int>? {
        val qs = NaiveBayes.tokens(q).filter { it !in stop }.toSet()
        if (qs.isEmpty()) return null
        val best = facts.maxByOrNull { f -> qs.count { it in f.keys } } ?: return null
        val score = qs.count { it in best.keys }
        return if (score >= 1) Pair(best.text, score) else null
    }

    fun randomFact(): String = facts.randomOrNull()?.text ?: "База фактов пуста, Сэр."
    fun joke(): String = jokes.randomOrNull() ?: "Шутки закончились, Сэр."
    fun size() = facts.size
}
