package com.shadiyar.friday.service

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.shadiyar.friday.FridayApp
import com.shadiyar.friday.ui.MainActivity

/**
 * После перезагрузки Android 15 не даёт сразу запускать микрофонный сервис,
 * поэтому показываем уведомление «Нажми, чтобы запустить Пятницу».
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val open = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).putExtra("autostart", true),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, FridayApp.CH_BOOT)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Нажми, чтобы запустить Пятницу")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(2, n)
        } catch (_: SecurityException) { /* нет разрешения на уведомления */ }
    }
}
