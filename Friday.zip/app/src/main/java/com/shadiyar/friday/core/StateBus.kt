package com.shadiyar.friday.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class AssistantState { OFF, IDLE, LISTENING, THINKING, SPEAKING }

data class Msg(val mine: Boolean, val text: String)

/** Общая «шина»: состояние, чат и подсказка (прогноз по цепи Маркова). */
object StateBus {
    private val _state = MutableStateFlow(AssistantState.OFF)
    val state: StateFlow<AssistantState> = _state
    fun set(s: AssistantState) { _state.value = s }

    private val _chat = MutableStateFlow<List<Msg>>(emptyList())
    val chat: StateFlow<List<Msg>> = _chat
    fun add(m: Msg) { _chat.value = (_chat.value + m).takeLast(200) }

    private val _hint = MutableStateFlow<String?>(null)
    val hint: StateFlow<String?> = _hint
    fun setHint(h: String?) { _hint.value = h }
}
