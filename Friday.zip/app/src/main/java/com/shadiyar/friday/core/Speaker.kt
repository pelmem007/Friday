package com.shadiyar.friday.core

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Озвучка через системный TTS. Флаг speaking нужен, чтобы микрофон не слушал сам себя. */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    @Volatile var speaking = false

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { speaking = true }
                    override fun onDone(id: String?) { speaking = false }
                    @Deprecated("deprecated")
                    override fun onError(id: String?) { speaking = false }
                })
                ready = true
            }
        }
    }

    fun speak(text: String) {
        if (!ready) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "f" + System.nanoTime())
    }
}
