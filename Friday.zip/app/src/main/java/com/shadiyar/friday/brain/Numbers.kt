package com.shadiyar.friday.brain

/** Vosk выдаёт числа словами («двадцать пять») — превращаем в цифры («25»). */
object Numbers {
    private val units = mapOf("ноль" to 0, "один" to 1, "одна" to 1, "одну" to 1, "одно" to 1, "два" to 2, "две" to 2,
        "три" to 3, "четыре" to 4, "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9,
        "десять" to 10, "одиннадцать" to 11, "двенадцать" to 12, "тринадцать" to 13, "четырнадцать" to 14,
        "пятнадцать" to 15, "шестнадцать" to 16, "семнадцать" to 17, "восемнадцать" to 18, "девятнадцать" to 19)
    private val tens = mapOf("двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50,
        "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90)
    private val hundreds = mapOf("сто" to 100, "двести" to 200, "триста" to 300, "четыреста" to 400,
        "пятьсот" to 500, "шестьсот" to 600, "семьсот" to 700, "восемьсот" to 800, "девятьсот" to 900)

    fun normalize(s: String): String {
        val out = mutableListOf<String>()
        var cur = -1
        var cls = 99
        fun flush() { if (cur >= 0) { out += cur.toString(); cur = -1; cls = 99 } }
        for (w in s.split(Regex("\\s+")).filter { it.isNotEmpty() }) {
            val (v, c) = when {
                hundreds.containsKey(w) -> Pair(hundreds.getValue(w), 3)
                tens.containsKey(w) -> Pair(tens.getValue(w), 2)
                units.containsKey(w) -> Pair(units.getValue(w), 1)
                else -> { flush(); out += w; continue }
            }
            if (cur >= 0 && c < cls) { cur += v; cls = c } else { flush(); cur = v; cls = c }
        }
        flush()
        return out.joinToString(" ")
    }
}
