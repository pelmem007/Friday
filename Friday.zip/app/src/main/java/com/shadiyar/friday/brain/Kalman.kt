package com.shadiyar.friday.brain

/** Одномерный фильтр Калмана: сглаживает «дрожащие» измерения (например, процент заряда). */
class Kalman1D(private val q: Float = 0.01f, private val r: Float = 1f) {
    private var x = 0f
    private var p = 1f
    private var init = false
    fun update(z: Float): Float {
        if (!init) { x = z; init = true; return x }
        p += q
        val k = p / (p + r)
        x += k * (z - x)
        p *= (1 - k)
        return x
    }
}
