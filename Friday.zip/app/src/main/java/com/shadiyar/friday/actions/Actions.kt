package com.shadiyar.friday.actions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat

/** Действия на телефоне. Запуск экранов из фона требует разрешения «Поверх других окон». */
object Actions {
    private val aliases = mapOf(
        "ютуб" to "youtube", "ютюб" to "youtube", "телеграм" to "telegram", "телеграмм" to "telegram",
        "ватсап" to "whatsapp", "вацап" to "whatsapp", "хром" to "chrome", "браузер" to "chrome",
        "камера" to "camera", "камеру" to "camera", "галерея" to "gallery", "галерею" to "gallery",
        "инстаграм" to "instagram", "тикток" to "tiktok", "калькулятор" to "calculator",
        "часы" to "clock", "карты" to "maps", "почта" to "gmail", "музыка" to "music"
    )

    private fun start(ctx: Context, i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    private fun hint(ctx: Context) =
        if (Settings.canDrawOverlays(ctx)) "" else " Если экран выключен — выдайте разрешение «Поверх других окон»."

    fun openApp(ctx: Context, name: String): String? {
        val pm = ctx.packageManager
        val n = name.trim().lowercase()
        val cand = listOfNotNull(n, aliases[n])
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { ri ->
            val l = ri.loadLabel(pm).toString().lowercase()
            cand.any { c -> l == c || (c.length >= 3 && l.contains(c)) }
        } ?: return null
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return null
        return if (start(ctx, i)) "Открываю ${hit.loadLabel(pm)}, Сэр.${hint(ctx)}" else "Не получилось открыть, Сэр."
    }

    fun dial(ctx: Context, who: String): String {
        val digits = who.filter { it.isDigit() }
        var number: String? = if (digits.length >= 5) digits else null
        if (number == null && ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            val a = who.trim()
            val b = a.replaceFirstChar { it.uppercase() }
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ? OR ${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$a%", "%$b%"), null
            )?.use { if (it.moveToFirst()) number = it.getString(0) }
        }
        val num = number ?: return "Не нашла контакт «$who», Сэр. Проверьте разрешение на контакты."
        return if (start(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))) "Набираю $who.${hint(ctx)}" else "Не вышло, Сэр."
    }

    fun web(ctx: Context, q: String): String =
        if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))) "Ищу «$q».${hint(ctx)}" else "Не вышло, Сэр."

    fun nav(ctx: Context, q: String): String =
        if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))))) "Показываю «$q».${hint(ctx)}" else "Не вышло, Сэр."

    fun torch(ctx: Context, on: Boolean): String = try {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return "Вспышки нет, Сэр."
        cm.setTorchMode(id, on)
        if (on) "Фонарик включён." else "Фонарик выключен."
    } catch (e: Exception) { "Не вышло, Сэр: ${e.message}" }

    fun volume(ctx: Context, up: Boolean): String = try {
        ctx.getSystemService(AudioManager::class.java).adjustStreamVolume(
            AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
        if (up) "Громче." else "Тише."
    } catch (e: Exception) { "Не вышло, Сэр." }

    fun battery(ctx: Context): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val s = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        if (l < 0) return "Не удалось узнать заряд, Сэр."
        val ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        return "Заряд ${l * 100 / s} процентов" + (if (ch) ", телефон на зарядке" else "") + ", Сэр."
    }
}
