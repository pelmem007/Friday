package com.shadiyar.friday.actions

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.shadiyar.friday.FridayApp
import com.shadiyar.friday.core.Speaker
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Срабатывание напоминаний: уведомление + голос (+ рингтон для будильника). */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val kind = intent.getStringExtra("kind") ?: "remind"
        var text = intent.getStringExtra("text") ?: ""
        if (kind == "briefing") {
            text = "Доброе утро, Сэр. Сегодня " + SimpleDateFormat("d MMMM, EEEE", Locale("ru")).format(Date()) + ". " + Actions.battery(ctx)
            Reminders.scheduleBriefing(ctx)   // на следующий день
        }
        if (kind == "alarm") {
            try {
                val r = RingtoneManager.getRingtone(ctx, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                r.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
                r.play()
                Handler(Looper.getMainLooper()).postDelayed({ r.stop() }, 30_000)
            } catch (_: Exception) {}
        }
        try {
            NotificationManagerCompat.from(ctx).notify(
                (System.currentTimeMillis() % 100000).toInt() + 10,
                NotificationCompat.Builder(ctx, FridayApp.CH_ALERT)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle("Пятница").setContentText(text)
                    .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build()
            )
        } catch (_: SecurityException) {}
        Speaker.init(ctx)
        Handler(Looper.getMainLooper()).postDelayed({ Speaker.speak(text) }, 800)
    }
}
