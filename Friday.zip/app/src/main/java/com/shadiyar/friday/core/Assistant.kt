package com.shadiyar.friday.core

import android.content.Context
import com.shadiyar.friday.brain.Brain
import com.shadiyar.friday.brain.Markov

/** Единая точка: текст -> Brain -> чат + озвучка + обновление прогноза Маркова. */
object Assistant {
    fun handle(ctx: Context, text: String, speak: Boolean = true): String {
        StateBus.add(Msg(true, text))
        val answer = try { Brain.reply(ctx, text) } catch (e: Exception) { "Сбой, Сэр: ${e.message}" }
        StateBus.add(Msg(false, answer))
        if (speak) Speaker.speak(answer)
        Markov.record(ctx, Brain.lastIntent)
        StateBus.setHint(Markov.predict(ctx, Brain.lastIntent)?.let { Brain.sample(it) })
        return answer
    }
}
