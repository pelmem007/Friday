package com.shadiyar.friday.brain

import kotlin.math.exp
import kotlin.math.ln

data class BayesResult(val label: String, val p: Double, val entropy: Double, val coverage: Double)

/** Наивный Байес по «основам» слов (первые 5 букв) + энтропия Шеннона как мера неуверенности. */
class NaiveBayes(data: Map<String, List<String>>) {
    private val vocab = HashSet<String>()
    private val counts = HashMap<String, HashMap<String, Int>>()
    private val totals = HashMap<String, Int>()
    private val priors = HashMap<String, Double>()

    companion object {
        fun tokens(s: String): List<String> =
            s.lowercase().split(Regex("[^а-яёa-z0-9]+")).filter { it.isNotEmpty() }
                .map { if (it.length > 5) it.substring(0, 5) else it }
    }

    init {
        val n = data.values.sumOf { it.size }.toDouble()
        for ((c, ps) in data) {
            priors[c] = ln(ps.size / n)
            val m = HashMap<String, Int>()
            var t = 0
            for (p in ps) for (w in tokens(p)) { m[w] = (m[w] ?: 0) + 1; t++; vocab += w }
            counts[c] = m
            totals[c] = t
        }
    }

    fun classify(text: String): BayesResult? {
        val all = tokens(text)
        val known = all.filter { it in vocab }
        if (known.isEmpty()) return null
        val v = vocab.size.toDouble()
        val logs = counts.keys.associateWith { c ->
            var s = priors.getValue(c)
            for (w in known) s += ln(((counts.getValue(c)[w] ?: 0) + 1.0) / (totals.getValue(c) + v))
            s
        }
        val mx = logs.values.max()
        val exps = logs.mapValues { exp(it.value - mx) }
        val sum = exps.values.sum()
        val probs = exps.mapValues { it.value / sum }
        val best = probs.maxByOrNull { it.value }!!
        val h = -probs.values.filter { it > 1e-12 }.sumOf { it * ln(it) / ln(2.0) }
        return BayesResult(best.key, best.value, h, known.size.toDouble() / all.size)
    }
}
