package com.shadiyar.friday.service

import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.shadiyar.friday.FridayApp
import com.shadiyar.friday.actions.Reminders
import com.shadiyar.friday.brain.Kalman1D
import com.shadiyar.friday.brain.Knowledge
import com.shadiyar.friday.core.Assistant
import com.shadiyar.friday.core.AssistantState
import com.shadiyar.friday.core.Speaker
import com.shadiyar.friday.core.StateBus
import com.shadiyar.friday.ui.MainActivity
import com.shadiyar.friday.voice.VoiceEngine

/** Foreground Service (microphone): слушает слово активации при выключенном экране и поверх других приложений. */
class FridayService : Service() {

    private var voice: VoiceEngine? = null
    private var wl: PowerManager.WakeLock? = null

    /** Следим за батареей: фильтр Калмана сглаживает проценты, при <=15% предупреждаем. */
    private val batt = object : BroadcastReceiver() {
        private val kalman = Kalman1D()
        private var warned = false
        override fun onReceive(c: Context, i: Intent) {
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            if (lvl < 0) return
            val p = kalman.update(lvl * 100f / sc)
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            if (!charging && p <= 15f && !warned) {
                warned = true
                Speaker.speak("Сэр, заряд ${p.toInt()} процентов. Пора на зарядку.")
            }
            if (charging || p > 20f) warned = false
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, FridayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, FridayApp.CH_SERVICE)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Пятница на связи")
            .setContentText("Скажите «Пятница», Сэр")
            .setContentIntent(open).addAction(0, "Остановить", stop).setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }

        if (voice == null) {
            Speaker.init(this)
            Knowledge.load(this)
            Reminders.scheduleBriefing(this)
            wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "friday:voice").also { it.acquire() }
            ContextCompat.registerReceiver(this, batt, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
            StateBus.set(AssistantState.IDLE)
            voice = VoiceEngine(applicationContext) { text -> Assistant.handle(applicationContext, text) }.also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        voice?.stop(); voice = null
        try { unregisterReceiver(batt) } catch (_: Exception) {}
        wl?.let { if (it.isHeld) it.release() }
        StateBus.set(AssistantState.OFF)
        super.onDestroy()
    }

    companion object { const val ACTION_STOP = "com.shadiyar.friday.STOP" }
}
