package com.shadiyar.friday.brain

import android.content.Context
import com.shadiyar.friday.actions.Actions
import com.shadiyar.friday.actions.Reminders
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Главный «мозг» без нейросетей: регулярки команд -> Байес -> память -> база знаний -> уточнение. */
object Brain {
    @Volatile var lastIntent = "NONE"

    private val phrases: Map<String, List<String>> = mapOf(
        "GREET" to listOf("привет", "здравствуй", "добрый день", "доброе утро", "добрый вечер", "хай", "здорово"),
        "HOWAREYOU" to listOf("как дела", "как ты", "как жизнь", "что нового"),
        "WHO" to listOf("кто ты", "как тебя зовут", "представься", "ты кто"),
        "THANKS" to listOf("спасибо", "благодарю", "молодец", "отлично"),
        "BYE" to listOf("пока", "до свидания", "до встречи", "споки"),
        "JOKE" to listOf("расскажи шутку", "пошути", "анекдот", "рассмеши меня"),
        "TIME" to listOf("который час", "сколько времени", "скажи время", "время"),
        "DATE" to listOf("какое сегодня число", "какая сегодня дата", "какой сегодня день", "дата"),
        "BATTERY" to listOf("сколько заряда", "заряд батареи", "батарея", "сколько процентов"),
        "FLASH_ON" to listOf("включи фонарик", "зажги свет", "включи фонарь", "фонарик"),
        "FLASH_OFF" to listOf("выключи фонарик", "погаси фонарик", "выключи фонарь"),
        "VOL_UP" to listOf("громче", "увеличь громкость", "сделай погромче", "прибавь звук"),
        "VOL_DOWN" to listOf("тише", "уменьши громкость", "сделай потише", "убавь звук"),
        "FACT" to listOf("расскажи факт", "интересный факт", "удиви меня", "что-нибудь интересное"),
        "HELP" to listOf("что ты умеешь", "помощь", "твои команды", "help")
    )
    private val nb = NaiveBayes(phrases)

    /** Пример фразы для подсказки Маркова. */
    fun sample(intent: String): String? = phrases[intent]?.firstOrNull()

    private fun done(intent: String, text: String): String { lastIntent = intent; return text }
    private fun unitMs(u: String) = when { u.startsWith("сек") -> 1000L; u.startsWith("мин") -> 60_000L; else -> 3_600_000L }

    fun reply(ctx: Context, raw: String): String {
        Knowledge.load(ctx)
        var t = Numbers.normalize(raw.lowercase().trim().trimEnd('.', '!', '?'))
        t = t.replace(Regex("^(эй |привет )?(пятница|джарвис)[,]?\\s*"), "").trim()
        if (t.isEmpty()) return done("GREET", "Слушаю, Сэр.")

        // --- память пользователя
        Regex("^запомни[:,]?\\s*(.+?)\\s*(?:=|—| это | - )\\s*(.+)$").find(t)?.let {
            UserMemory.remember(ctx, it.groupValues[1], it.groupValues[2]); return done("REMEMBER", "Запомнила, Сэр.")
        }
        Regex("^забудь\\s+(.+)$").find(t)?.let {
            return done("FORGET", if (UserMemory.forget(ctx, it.groupValues[1])) "Забыла, Сэр." else "Такого у меня нет, Сэр.")
        }

        // --- калькулятор
        val ct = t.replace(" плюс ", "+").replace(" минус ", "-").replace(" умножить на ", "*")
            .replace(" умножь на ", "*").replace(" разделить на ", "/").replace(" делить на ", "/")
        calc(ct)?.let { return done("CALC", "Получается $it, Сэр.") }

        // --- таймер, будильник, напоминания
        Regex("таймер.*?(?:(\\d+)\\s+)?(секунд\\S*|минут\\S*|час\\S*)").find(t)?.let {
            val n = it.groupValues[1].toLongOrNull() ?: 1L
            val ms = n * unitMs(it.groupValues[2])
            Reminders.schedule(ctx, System.currentTimeMillis() + ms, "timer", "Таймер сработал, Сэр.")
            return done("TIMER", "Таймер запущен: $n ${it.groupValues[2]}.")
        }
        Regex("будильник\\s+(?:на\\s+)?(\\d{1,2})(?:[:. ]\\s*(\\d{2}))?").find(t)?.let {
            var h = it.groupValues[1].toInt(); val m = it.groupValues[2].toIntOrNull() ?: 0
            if ((t.contains("вечера") || t.contains("дня")) && h < 12) h += 12
            if (h > 23 || m > 59) return done("ALARM", "Не поняла время, Сэр.")
            Reminders.schedule(ctx, Reminders.nextAt(h, m), "alarm", "Будильник, Сэр. Пора вставать.")
            return done("ALARM", "Будильник на %02d:%02d.".format(h, m))
        }
        Regex("напомни(?:\\s+мне)?\\s+через\\s+(?:(\\d+)\\s+)?(секунд\\S*|минут\\S*|час\\S*)\\s*(.*)$").find(t)?.let {
            val n = it.groupValues[1].toLongOrNull() ?: 1L
            val what = it.groupValues[3].ifBlank { "Время вышло" }
            Reminders.schedule(ctx, System.currentTimeMillis() + n * unitMs(it.groupValues[2]), "remind", "Напоминаю, Сэр: $what")
            return done("REMIND", "Напомню через $n ${it.groupValues[2]}.")
        }
        Regex("напомни(?:\\s+мне)?\\s+в\\s+(\\d{1,2})(?:[:. ]\\s*(\\d{2}))?\\s+(.+)$").find(t)?.let {
            val h = it.groupValues[1].toInt(); val m = it.groupValues[2].toIntOrNull() ?: 0
            if (h > 23 || m > 59) return done("REMIND", "Не поняла время, Сэр.")
            Reminders.schedule(ctx, Reminders.nextAt(h, m), "remind", "Напоминаю, Сэр: ${it.groupValues[3]}")
            return done("REMIND", "Напомню в %02d:%02d.".format(h, m))
        }

        // --- действия на телефоне
        Regex("^(?:позвони|набери|вызови)\\s+(.+)$").find(t)?.let { return done("CALL", Actions.dial(ctx, it.groupValues[1])) }
        Regex("^(?:найди|поищи|загугли|погугли)\\s+(.+)$").find(t)?.let { return done("WEB", Actions.web(ctx, it.groupValues[1])) }
        Regex("^(?:проложи маршрут до|маршрут до|навигация до|как доехать до|покажи на карте)\\s+(.+)$").find(t)?.let {
            return done("NAV", Actions.nav(ctx, it.groupValues[1]))
        }
        Regex("^(?:открой|запусти|включи)\\s+(?!фонар)(.+)$").find(t)?.let { m ->
            Actions.openApp(ctx, m.groupValues[1])?.let { return done("OPEN", it) }
        }

        // --- знания по ключевым словам (сильное совпадение), потом Байес
        val k = Knowledge.search(t)
        if (k != null && k.second >= 2) return done("FACTQ", k.first)

        val r = nb.classify(t)
        if (r != null && r.p >= 0.6 && r.entropy <= 1.6 && r.coverage >= 0.6) return intentReply(ctx, r.label)

        UserMemory.recall(ctx, t)?.let { return done("RECALL", it) }
        if (k != null) return done("FACTQ", k.first)

        if (r != null && r.p >= 0.35) {
            val s = sample(r.label)
            if (s != null) return done("NONE", "Не уверена, Сэр. Вы имели в виду: «$s»?")
        }
        return done("NONE", "Пока не знаю, как на это ответить, Сэр. Можете уточнить?")
    }

    private fun intentReply(ctx: Context, label: String): String = done(label, when (label) {
        "GREET" -> listOf("Слушаю, Сэр.", "Здравствуйте, Сэр.", "Привет, Сэр. Чем могу помочь?").random()
        "HOWAREYOU" -> "Системы в норме, Сэр. А у вас?"
        "WHO" -> "Я Пятница, ваш личный ассистент, Сэр."
        "THANKS" -> "Всегда пожалуйста, Сэр."
        "BYE" -> "До связи, Сэр."
        "JOKE" -> Knowledge.joke()
        "FACT" -> Knowledge.randomFact()
        "TIME" -> "Сейчас " + SimpleDateFormat("HH:mm", Locale("ru")).format(Date()) + ", Сэр."
        "DATE" -> "Сегодня " + SimpleDateFormat("d MMMM yyyy, EEEE", Locale("ru")).format(Date()) + "."
        "BATTERY" -> Actions.battery(ctx)
        "FLASH_ON" -> Actions.torch(ctx, true)
        "FLASH_OFF" -> Actions.torch(ctx, false)
        "VOL_UP" -> Actions.volume(ctx, true)
        "VOL_DOWN" -> Actions.volume(ctx, false)
        "HELP" -> "Умею: время и дата, калькулятор, таймеры, будильники и напоминания, открыть приложение, позвонить, найти в интернете, маршрут, фонарик, громкость, заряд, факты и шутки. Ещё запоминаю: «запомни: ключ = значение»."
        else -> "Слушаю, Сэр."
    })

    private fun calc(s: String): String? {
        val m = Regex("(-?\\d+(?:[.,]\\d+)?)\\s*([+\\-*/x×:÷])\\s*(-?\\d+(?:[.,]\\d+)?)").find(s) ?: return null
        val a = m.groupValues[1].replace(',', '.').toDouble()
        val b = m.groupValues[3].replace(',', '.').toDouble()
        val r = when (m.groupValues[2]) {
            "+" -> a + b
            "-" -> a - b
            "*", "x", "×" -> a * b
            "/", ":", "÷" -> if (b == 0.0) return "деление на ноль невозможно" else a / b
            else -> return null
        }
        return if (r == Math.floor(r) && Math.abs(r) < 1e12) r.toLong().toString()
        else String.format(Locale.US, "%.4f", r).trimEnd('0').trimEnd('.')
    }
}
