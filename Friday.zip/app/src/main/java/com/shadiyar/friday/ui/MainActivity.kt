package com.shadiyar.friday.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.shadiyar.friday.brain.Knowledge
import com.shadiyar.friday.core.Assistant
import com.shadiyar.friday.core.AssistantState
import com.shadiyar.friday.core.Speaker
import com.shadiyar.friday.core.StateBus
import com.shadiyar.friday.service.FridayService

/** Главный экран: чат, запуск фонового режима, кнопки разрешений. */
class MainActivity : ComponentActivity() {

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.RECORD_AUDIO] == true) startAssistant()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Speaker.init(this)
        Knowledge.load(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF00E5FF))) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF050B10)) { Screen() }
            }
        }
        if (intent.getBooleanExtra("autostart", false)) ensurePermsAndStart()
    }

    private fun ensurePermsAndStart() {
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        val missing = need.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startAssistant() else permLauncher.launch(missing.toTypedArray())
    }

    private fun startAssistant() {
        ContextCompat.startForegroundService(this, Intent(this, FridayService::class.java))
    }

    private fun stopAssistant() {
        startService(Intent(this, FridayService::class.java).setAction(FridayService.ACTION_STOP))
    }

    @Composable
    private fun Screen() {
        val state by StateBus.state.collectAsState()
        val chat by StateBus.chat.collectAsState()
        val hint by StateBus.hint.collectAsState()
        val list = rememberLazyListState()
        var input by remember { mutableStateOf("") }
        LaunchedEffect(chat.size) { if (chat.isNotEmpty()) list.animateScrollToItem(chat.size - 1) }

        Column(Modifier.fillMaxSize().padding(12.dp).statusBarsPadding().navigationBarsPadding().imePadding()) {
            Text("П Я Т Н И Ц А", color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace)
            Text("Состояние: $state · фактов: ${Knowledge.size()}", color = Color.Gray, fontFamily = FontFamily.Monospace)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { ensurePermsAndStart() }, enabled = state == AssistantState.OFF) { Text("Запустить") }
                OutlinedButton(onClick = { stopAssistant() }, enabled = state != AssistantState.OFF) { Text("Стоп") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }) { Text("Поверх окон") }
                TextButton(onClick = {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }) { Text("Батарея") }
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), state = list) {
                items(chat) { m ->
                    Text(
                        (if (m.mine) "Вы: " else "Пятница: ") + m.text,
                        color = if (m.mine) Color.White else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
            hint?.let { h ->
                AssistChip(onClick = { Assistant.handle(applicationContext, h) }, label = { Text("Сэр, обычно дальше: «$h»") })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f), placeholder = { Text("Спросите что-нибудь…") })
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    if (input.isNotBlank()) { Assistant.handle(applicationContext, input); input = "" }
                }) { Text("➤") }
            }
        }
    }
}
